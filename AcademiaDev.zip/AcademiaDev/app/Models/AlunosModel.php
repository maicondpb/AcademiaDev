<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class AlunosModel extends ConnectionController
{

    public object $conn;
    
    public function dadosAluno(){

        $this->conn = $this->connectDb();

        $sql = "SELECT * from alunos  ORDER BY nome ASC";
        $sql_query = $this->conn->prepare($sql);
        $sql_query->execute();

        $sql_dadosAluno = $sql_query->fetchAll();
        return $sql_dadosAluno;

    }


    

   
}