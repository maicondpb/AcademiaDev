<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class DisciplinasModel extends ConnectionController
{

    public object $conn;
    
    public function dadosDisciplina(){

        $this->conn = $this->connectDb();

        $sql = "SELECT * from disciplina ORDER BY nome ASC";
        $sql_query = $this->conn->prepare($sql);
        $sql_query->execute();

        $sql_dadosDisciplina = $sql_query->fetchAll();
        return $sql_dadosDisciplina;

    }
}