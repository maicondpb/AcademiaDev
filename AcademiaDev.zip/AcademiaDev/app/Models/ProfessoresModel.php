<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class ProfessoresModel extends ConnectionController
{

    public object $conn;
    
    public function dadosProfessor(){

        $this->conn = $this->connectDb();

        $sql = "SELECT * from professores ORDER BY nome ASC";
        $sql_query = $this->conn->prepare($sql);
        $sql_query->execute();

        $sql_dadosProfessor = $sql_query->fetchAll();
        return $sql_dadosProfessor;

    }
}