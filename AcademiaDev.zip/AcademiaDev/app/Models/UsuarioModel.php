<?php
session_start();
class UsuarioModel extends ConnectionController
{

    public object $conn;

    public function logar($email, $senha){

        $this->conn = $this->connectDb();
        $sql = "SELECT * FROM `alunos` WHERE `email` = '$email' AND `senha` = md5('$senha') AND `situacao_id` = 1 AND `nivelAcesso_id` = 2 OR 3 LIMIT 1";
        $sql_query = $this->conn->prepare($sql);
        $sql_query->execute();
        $sql_dados = $sql_query->fetchAll();
        if($sql_dados){

            $_SESSION['id']   = $sql_dados[0]['id'];
            $_SESSION['nivelAcesso_id'] = $sql_dados[0]['nivelAcesso_id'];
            $_SESSION['nome'] = $sql_dados[0]['nome'];
            $_SESSION['situacao_id'] = $sql_dados[0]['situacao_id'];
            $rowCount = count($sql_dados);
        
            return $rowCount;

        }else{

            $_SESSION['avisoLogin']= "<p>"."Senha ou Email invalido"."</br>"."Entre em contato com o suporte"."</p>";
        }
        

        
    
        
    }

}