<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class TurmasModel extends ConnectionController
{

    public object $conn;
    
    public function dadosTurma(){

        $this->conn = $this->connectDb();

        $sql = "SELECT * from turma ORDER BY nome ASC";
        $sql_query = $this->conn->prepare($sql);
        $sql_query->execute();

        $sql_dadosTurma = $sql_query->fetchAll();
        return $sql_dadosTurma;

    }

}