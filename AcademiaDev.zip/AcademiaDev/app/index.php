<?php
session_start();


define('C7E3L8K9E58743', true);

$url = filter_input(INPUT_GET,'url',FILTER_DEFAULT);

//Config
include_once 'config/config.php';

//core
include_once "core/Core.php";

//Controllers
include_once 'Controllers/ConnectionController.php';
include_once 'Controllers/UsuarioController.php';
include_once 'Controllers/Error404Controller.php';
include_once 'Controllers/DashboardController.php';
include_once 'Controllers/ProfessoresController.php';
include_once 'Controllers/AlunosController.php';
include_once 'Controllers/TurmasController.php';
include_once 'Controllers/DisciplinasController.php';
include_once 'Controllers/CadastrardisciplinaController.php';
include_once 'Controllers/LogoutController.php';
include_once 'Controllers/CardsdashboardController.php';



//Model
include_once 'Models/UsuarioModel.php';
include_once 'Controllers/Error404Model.php';
include_once 'Models/DashboardModel.php';
include_once 'Models/ProfessoresModel.php';
include_once 'Models/AlunosModel.php';
include_once 'Models/TurmasModel.php';
include_once 'Models/DisciplinasModel.php';
include_once 'Models/LogoutModel.php';
include_once 'Models/CardsdashboardModel.php';



$arr_url = explode("/",$url);

$controller  = $arr_url[0];
$metodo    = $arr_url[1];
$parametro = $arr_url[2];


$index = new Core();
$index->index($controller, $metodo, $parametro);

if($_POST){
    $email = trim(filter_input(INPUT_POST,'email',FILTER_DEFAULT));
    $senha = trim(filter_input(INPUT_POST,'password',FILTER_DEFAULT));

    if(!empty($email) && !empty($senha)){

        $index = new UsuarioController();

        $p = $index->loginSystem($email,$senha);

        if($p == 1){
            header("Location: " . DOMINIO . "dashboard");
        }else{
            
            header("Location: " . DOMINIO);
        }  

    }else{
        header("Location: " . DOMINIO);
    }
}

