<?php

if(!defined('C7E3L8K9E58743')){

    header('Location: ' . DOMINIO);

}else{
    
    ?>
        <!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Error 404</title>

            <!-- css -->
            <link rel="stylesheet" href="<?= DOMINIO ?>assets/css/style.css">
        </head>
        <body>

        <div class="login">
	        <h1>ERROR 404</h1>
                <form action="http://localhost:8001/">
                    <button type="submit" class="btn btn-primary btn-block btn-large">Voltar para Início</button>
                </form>
        </div>

            </main>
            
        </body>
        </html>
    <?php

}