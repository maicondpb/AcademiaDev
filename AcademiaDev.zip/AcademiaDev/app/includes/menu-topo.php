
<div class="menu-topo">

    <div class="d-flex justify-content-between">
        <div>
            <li class="icon_user"><i class="fa fa-user-circle" aria-hidden="true"></i>&nbsp;</li>
        </div>
        <div>
            <li class="btn_sair"><a href="http://localhost:8001/logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;Sair</a></li>
        </div>
    </div>

</div>