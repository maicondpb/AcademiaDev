<style>

</style>
<div class="menu">
    <h2 class="text-center text-light">Menu</h1>
    <ul>
        <li><a href="<?= DOMINIO . "dashboard" ?>"><i class="fa fa-tachometer" aria-hidden="true"></i>  &nbsp; &nbsp;Dashboard</a></li>
        <li><a href="<?= DOMINIO . "alunos" ?>"><i class="fa fa-user" aria-hidden="true"></i>  &nbsp; &nbsp;Alunos</a></li>
        <li><a href="<?= DOMINIO . "professores" ?>"><i class="fa fa-user" aria-hidden="true"></i>  &nbsp; &nbsp;Professores</a></li>
        <li><a href="<?= DOMINIO . "turmas" ?>"><i class="fa fa-users" aria-hidden="true"></i> &nbsp; &nbsp;Turmas</a></li>
        <li><a href="<?= DOMINIO . "disciplinas" ?>"><i class="fa fa-book" aria-hidden="true"></i> &nbsp; &nbsp;Disciplinas</a></li>
    </ul>

</div>