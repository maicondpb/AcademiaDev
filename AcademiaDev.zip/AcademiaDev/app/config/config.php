<?php

define("DOMINIO","http://localhost:8001/");