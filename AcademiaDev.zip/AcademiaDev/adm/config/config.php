<?php

define("DOMINIO","http://localhost:8000/");