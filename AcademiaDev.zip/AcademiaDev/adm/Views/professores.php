<?php

if(!defined('C7E3L8K9E58743')){

    header('Location: ' . DOMINIO);

}else{

    if(isset($_SESSION['id']) && isset($_SESSION['nivelAcesso_id']) && isset($_SESSION['nome']) && isset($_SESSION['situacao_id'])){
    
    $arr_url = explode("/", $_SERVER['REQUEST_URI']);
    $r = new ProfessoresController();

?>


<?php
    if($arr_url[2] == "editar"){
        include_once "/var/www/html/Views/editarprofessores.php";
    }else {
        
        ?>

<!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
            <link rel="stylesheet" href="<?= DOMINIO ?>assets/css/style.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
            <link  rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        </head>
        
        <body>
        
        <div class="d-flex">

            <?php include_once "/var/www/html/includes/menu-left.php" ?>
    
            <div class="conteudo">

                <?php include_once "/var/www/html/includes/menu-topo.php"; ?>

                <div class="conteudo_dados">
                    <br/>
                    <div class="d-flex justify-content-between">
                        <h4>Lista de Professores</h4>
                        <a href="<?= DOMINIO . "cadastrarprofessor" ?>"class="btn link" href="">Novo Professor</a>
                    </div>
                    <br/>
                        <div class="m-3">
                            <table class="table text-white table-bg">
                                <thead>
                                    <tr>
                                        <th scope="col">Nome</th>
                                        <th scope="col">CPF</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Telefone</th>
                                        <th scope="col">Sexo</th>
                                        <th scope="col">Data de Nascimento</th>
                                        <th scope="col">...</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        if(count($r->showProfessores()) > 0) {
                            
                                            foreach ($r->showProfessores() as $key => $dados_p) {

                                                echo "<tr>";
                                                echo "<td>" .  $dados_p['nome'] . "</td>";
                                                echo "<td>" .  $dados_p['cpf'] . "</td>";
                                                echo "<td>" .  $dados_p['email'] . "</td>";
                                                echo "<td>" .  $dados_p['telefone'] . "</td>";
                                                echo "<td>" .  $dados_p['sexo'] . "</td>";
                                                echo "<td>" .  $dados_p['dataNascimento'] . "</td>";
                                                echo "<td>"
                                                ?> 
                                                <a class='btn btn-sm btn-primary' href="<?= DOMINIO ?>editarprofessores?id=<?= $dados_p[0] ?>&editar=true">                                                                                                                                                                                                                                                
                                                    <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-pencil' viewBox='0 0 16 16'>
                                                        <path d='M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z'/>
                                                    </svg>
                                                    </a>
                                                    <a class='btn btn-sm btn-danger' href="<?= DOMINIO ?>deletarprofessores?id=<?= $dados_p[0] ?>&excluir=true">
                                                        <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-trash-fill' viewBox='0 0 16 16'>
                                                            <path d='M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z'/>
                                                        </svg>
                                                    </a>
                                                <?php 
                                                    "</td>";
                                                    echo "</tr>";

                                                }
                                            }
                                        ?>
                                    </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </body>
    </html>
    <?php
    
    
    }
}else{

    header('Location: ' . DOMINIO);

}


}