<?php
session_start();
 
$arr_url = explode("?",$_SERVER['REQUEST_URI']);

$arr_dados_aluno = explode("&",$arr_url[1]);


if($arr_dados_aluno[1] == "excluir=true"){

    $id = explode("=",$arr_dados_aluno[0]);
    $dados_delete = new DeletaralunosController();
    $dados_delete->deleteAluno($id[1]);

}