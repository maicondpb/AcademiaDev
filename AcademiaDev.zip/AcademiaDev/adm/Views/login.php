<?php
session_start();

if(!defined('C7E3L8K9E58743')){

    header('Location: ' . DOMINIO);

}else{
    ?>
        <!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
            <title>AcademiadDev - SCI</title>

            <!-- css -->
            <link rel="stylesheet" href="<?= DOMINIO ?>assets/css/style.css">
        </head>
        <body>
            <div id="logo">

                <img src="assets/images/logo-sci.png" alt="logo sci" />

            </div>

            <div class="login">
	            <h1>AcademiaDev</h1>
                    <form method="post" action="index.php">

    	            <input type="email" name="email" placeholder="Email" required="required" />
                        <input type="password" name="password" placeholder="Senha" required="required" />
                        <button type="submit" class="btn btn-primary btn-block btn-large">Acessar</button>
                        <?php
                            if(isset($_SESSION['avisoLogin'])){
                                echo $_SESSION['avisoLogin'];
                                unset($_SESSION['avisoLogin']);
                            }
                    ?>
                    </form>
        </div>

            </main>
            
        </body>
        </html>
    <?php

}