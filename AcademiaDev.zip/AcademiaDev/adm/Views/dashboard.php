<?php
    

if(!defined('C7E3L8K9E58743')){

    header('Location: ' . DOMINIO);
    
}else{

    if(isset($_SESSION['id']) && isset($_SESSION['nivelAcesso_id']) && isset($_SESSION['nome']) && isset($_SESSION['situacao_id'])){
        $rd = new CardsdashboardController();
       
    
    ?>

<!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            
            <link rel="stylesheet" href="<?= DOMINIO ?>assets/css/style.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
            <link  rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
            <link href="https://fonts.googleapis.com/css?family=Open+Sans:300i,400" rel="stylesheet">
            
        </head>
        <body>
        
        <div class="d-flex">

            <?php include_once "/var/www/html/includes/menu-left.php" ?>
    
            <div class="conteudo">

                <?php include_once "/var/www/html/includes/menu-topo.php"; ?>

                <div class="conteudo_dados">
                    <div class="container">
                        <div class="card">
                            <h3 class="title">&nbsp;&nbsp;&nbsp;Alunos</h3>
                            <div class="bar">
                            <div class="emptybar"></div>
                            <div class="filledbar"></div>
                            </div>
                            <div class="circle">
                                <div class="bg-dark d-flex justify-content-center align-items-center circulo rounded-circle"><?php echo $rd->listarA()?></div>
                            </div>
                            <div class="goview">
                                <label type="button" ><a href="<?= DOMINIO . "alunos" ?>">>></a></label>
                            </div>
                        </div>
                        <div class="card">
                            <h3 class="title">&nbsp;&nbsp;&nbsp;Professores</h3>
                            <div class="bar">
                            <div class="emptybar"></div>
                            <div class="filledbar"></div>
                            </div>
                            <div class="circle">
                                <div class="bg-dark d-flex justify-content-center align-items-center circulo rounded-circle"><?php echo $rd->listarP()?></div>
                            </div>
                            <div class="goview">
                                <label type="button" ><a href="<?= DOMINIO . "professores" ?>">>></a></label>
                            </div>
                        </div>
                        <div class="card">
                            <h3 class="title">&nbsp;&nbsp;&nbsp;Turmas</h3>
                            <div class="bar">
                            <div class="emptybar"></div>
                            <div class="filledbar"></div>
                            </div>
                            <div class="circle">
                                <div class="bg-dark d-flex justify-content-center align-items-center circulo rounded-circle"><?php echo $rd->listarT()?> </div>
                            </div>
                            <div class="goview">
                                <label type="button" ><a href="<?= DOMINIO . "turmas" ?>">>></a></label>
                            </div>
                        </div>
                        <div class="card">
                            <h3 class="title">&nbsp;&nbsp;&nbsp;Disciplinas</h3>
                            <div class="bar">
                            <div class="emptybar"></div>
                            <div class="filledbar"></div>
                            </div>
                            <div class="circle">
                                <div class="bg-dark d-flex justify-content-center align-items-center circulo rounded-circle"><?php echo $rd->listarD()?></div>
                            </div>
                            <div class="goview">
                                <label type="button" ><a href="<?= DOMINIO . "disciplinas" ?>">>></a></label>
                            </div>
                        </div>
                    </div>
            </div>
        </div>


        </body>
        </html>
    <?php

    }else{
        header('Location: ' . DOMINIO);
    }
}