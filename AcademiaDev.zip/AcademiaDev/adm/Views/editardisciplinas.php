<?php
session_start();

if(!defined('C7E3L8K9E58743')){

    header('Location: ' . DOMINIO);

}else{

    $arr_url = explode("?",$_SERVER['REQUEST_URI']);
    $arr_dados_disciplina = explode("&",$arr_url[1]);

    $id = explode("=", $arr_dados_disciplina[0]);
    $_SESSION['id'] = $id[1];

    $t = new DisciplinasController();


    if($_POST){
        $r = new EditardisciplinasController();
        $r->editarDisciplina($_POST);
    }

    ?>
        <!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">

            <link rel="stylesheet" href="<?= DOMINIO ?>assets/css/style.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
        </head>
            
        <body>
            
        <div class="d-flex">

            <?php include_once "/var/www/html/includes/menu-left.php" ?>
        
            <div class="conteudo">

                <?php include_once "/var/www/html/includes/menu-topo.php"; ?>

                <div class="conteudo_dados">
                    <br/>
                    <div class="d-flex justify-content-between">

            <title>Cadastro de Disciplinas</title>
            
            <style>
                body{
                    width: 100%;
                    height:100%;
                    font-family: 'Open Sans', sans-serif;
                    background: #092756;
                    background: -moz-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%),-moz-linear-gradient(top,  rgba(57,173,219,.25) 0%, rgba(42,60,87,.4) 100%), -moz-linear-gradient(-45deg,  #670d10 0%, #092756 100%);
                    background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -webkit-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -webkit-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
                    background: -o-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -o-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -o-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
                    background: -ms-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -ms-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -ms-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
                    background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), linear-gradient(to bottom,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), linear-gradient(135deg,  #670d10 0%,#092756 100%);
                    filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#3E1D6D', endColorstr='#092756',GradientType=1 );
                }
                .box{
                    color: white;
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%,-50%);
                    background-color: rgba(0, 0, 0, 0.6);
                    padding: 15px;
                    border-radius: 15px;
                    width: 20%;
                }
                fieldset{
                    border: 3px solid linear-gradient(to right,rgb(0, 92, 197), rgb(90, 20, 220));
                }
                legend{
                    border: 1px solid dodgerblue;
                    padding: 10px;
                    text-align: center;
                    background-image: linear-gradient(to right,rgb(0, 92, 197), rgb(90, 20, 220));
                    border-radius: 8px;
                }
                .inputBox{
                    position: relative;
                }
                .inputUser{
                    background: none;
                    border: none;
                    border-bottom: 1px solid white;
                    outline: none;
                    color: white;
                    font-size: 15px;
                    width: 100%;
                    letter-spacing: 2px;
                    top: -30px;
                }
                .labelInput{
                    position: absolute;
                    top: -30px;
                    left: 0px;
                    pointer-events: none;
                    transition: .5s;
                }
                /* .inputUser:focus ~ .labelInput,
                .inputUser:valid ~ .labelInput{
                    top: -15px;
                    font-size: 12px;
                    color: dodgerblue;
                } */
                #data_nascimento{
                    border: none;
                    padding: 8px;
                    border-radius: 10px;
                    outline: none;
                    font-size: 15px;
                }
                .submit{
                    background-image: linear-gradient(to right,rgb(0, 92, 197), rgb(90, 20, 220));
                    width: 100%;
                    border: none;
                    padding: 15px;
                    color: white;
                    font-size: 15px;
                    cursor: pointer;
                    border-radius: 10px;
                }
                .submit:hover{
                    background-image: linear-gradient(to right,rgb(0, 80, 172), rgb(80, 19, 195));
                }
                .Início > a {
                    color: white; 
                }
                .center{
                    display: flex;
                    justify-content: center;
                    margin-top: 8px;
                }
                
            </style>
        </head>
        <body>
            <div class="box">
                <form action="" method="POST">
                    <?php
                    foreach($t->dadosDisciplinaunico($id[1]) as $dados_unico_d){
                        ?>
                    
                    <fieldset>
                        <legend><b>Cadastro de Disciplina</b></legend>
                        <input type="hidden" name="id" value="<?= $dados_unico_d['id'] ?>">
                        <br>
                        <br>
                        <div class="inputBox">
                            <input type="text" name="nome" id="nome" class="inputUser" value="<?= $dados_unico_d['nome'] ?>" required>
                            <label for="nome" class="labelInput">Nome da Disciplina</label>
                        </div>
                        <br><br>
                            
                        <button type="submit" class="submit">Salvar</button>
                    
                    </fieldset>
                            <?php
                    }

                    ?>

                    <div class="center">

                        <label type="text" class="Início"><a href="<?= DOMINIO . "dashboard" ?>">Início</a></label>

                    </div>

                </form>
            </div>
        </body>
        </html>
    <?php
}