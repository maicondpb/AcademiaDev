<?php
session_start();
 
$arr_url = explode("?",$_SERVER['REQUEST_URI']);

$arr_dados_turma = explode("&",$arr_url[1]);


if($arr_dados_turma[1] == "excluir=true"){

    $id = explode("=",$arr_dados_turma[0]);
    $dados_delete_t = new DeletarturmasController();
    $dados_delete_t->deleteTurma($id[1]);

}


