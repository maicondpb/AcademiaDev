<?php

class Error404Controller
{
    
    public function sair(){

        unset($_SESSION);
        include_once "/var/www/html/Views/error404.php";

    }

}