<?php

class DeletarturmasController
{

    public function deleteTurma($id){

        $dados_delete_t = new DeletarturmasModel();
        return $dados_delete_t->deletarTurma($id);

    }
}