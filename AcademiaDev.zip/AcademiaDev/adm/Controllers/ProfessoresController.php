<?php

class ProfessoresController
{
    public function showProfessores(){

        $dados_p = new ProfessoresModel();
        return $dados_p->dadosProfessor();
    }

    public function dadosProfessorunico($id){

        $dados_unico_p = new ProfessoresModel();
        return $dados_unico_p->dadosProfessorunico($id);
        
    }

    

}

