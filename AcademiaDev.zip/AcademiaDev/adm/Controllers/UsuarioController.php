<?php
session_start();
class UsuarioController
{
    public function loginSystem($email,$senha){
        
        $usuario = new UsuarioModel();
        return $usuario->logar($email,$senha);
        
    }

   
}
