<?php

class CadastraralunoController
{
    public function novoAluno($aluno_create){

        $aluno_c = new CadastraralunoModel();
        return $aluno_c->newAluno($aluno_create);

    }
    

}