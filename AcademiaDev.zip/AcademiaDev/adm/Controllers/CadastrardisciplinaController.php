<?php

class CadastrardisciplinaController
{
    public function novaDisciplina($disciplina_create){

        $disciplina_c = new CadastrardisciplinaModel();
        return $disciplina_c->newDisciplina($disciplina_create);

    }
    

}