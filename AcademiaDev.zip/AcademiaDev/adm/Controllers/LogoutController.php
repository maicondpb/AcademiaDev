<?php

class LogoutController
{
    
    public function sair(){

       

    }

}