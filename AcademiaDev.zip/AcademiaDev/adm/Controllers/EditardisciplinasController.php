<?php

class EditardisciplinasController
{

    public function editarDisciplina($dados_edit){
        $editarDisciplina = new EditardisciplinasModel();
        return $editarDisciplina->editar($dados_edit);
    }

}