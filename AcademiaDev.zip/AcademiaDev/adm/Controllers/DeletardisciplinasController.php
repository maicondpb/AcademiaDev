<?php

class DeletardisciplinasController
{

    public function deleteDisciplina($id){

        $dados_delete_d = new DeletardisciplinasModel();
        return $dados_delete_d->deletarDisciplina($id);

    }
}