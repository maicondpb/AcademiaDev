<?php

class TurmasController
{
    public function showTurmas(){

        $dados_t = new TurmasModel();
        return $dados_t->dadosTurma();
    }

    public function dadosTurmaunico($id){

        $dados_unico_t = new TurmasModel();
        return $dados_unico_t->dadosTurmaunico($id);
        
    }

    

}