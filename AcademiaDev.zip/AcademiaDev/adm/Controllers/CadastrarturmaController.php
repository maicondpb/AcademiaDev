<?php

class CadastrarturmaController
{
    public function novaTurma($turma_create){

        $turma_c = new CadastrarturmaModel();
        return $turma_c->newTurma($turma_create);

    }
    

}