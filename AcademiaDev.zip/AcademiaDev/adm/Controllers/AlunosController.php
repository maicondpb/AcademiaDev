<?php

class AlunosController
{   
    public function showAlunos(){

        $dados = new AlunosModel();
        return $dados->dadosAluno();
    }

    public function dadosAlunounico($id){

        $dados_unico = new AlunosModel();
        return $dados_unico->dadosAlunounico($id);
        
    }

   

    

}