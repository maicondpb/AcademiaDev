<?php

class EditarprofessoresController
{

    public function editarProfessor($dados_edit){
        
        $editarProfessor = new EditarprofessoresModel();
        return $editarProfessor->editar($dados_edit);
    }

}