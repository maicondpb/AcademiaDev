<?php

class DeletarprofessoresController
{

    public function deleteProfessor($id){

        $dados_delete_p = new DeletarprofessoresModel();
        return $dados_delete_p->deletarProfessor($id);

    }
}