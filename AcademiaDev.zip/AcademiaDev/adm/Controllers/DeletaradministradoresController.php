<?php

class DeletaradministradoresController
{

    public function deleteAdministrador($id){

        $dados_delete_adm = new DeletaradministradoresModel();
        return $dados_delete_adm->deletarAdministrador($id);

    }
}