<?php

class DisciplinasController
{
    public function showDisciplinas(){

        $dados_d = new DisciplinasModel();
        return $dados_d->dadosDisciplina();
    }

    public function dadosDisciplinaunico($id){

        $dados_unico_d = new DisciplinasModel();
        return $dados_unico_d->dadosDisciplinaunico($id);
        
    }

    

}