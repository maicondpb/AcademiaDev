<?php

class EditaradministradoresController
{

    public function editarAdministrador($dados_edit){
        $editarAdministrador = new EditaradministradoresModel();
        return $editarAdministrador->editar($dados_edit);
    }

}