<?php

abstract class ConnectionController
{

    public $drive  = "mysql";
    public string $host   = "BancoEscolinha";
    public string $user   = "root";
    public string $pass   = "root";
    public string $dbname = "Academia_SCI";
    public int $port      = 3306;
    public object $connection;

    public function connectDb()
    {
        try {
            
            $this->connection = new PDO($this->drive . ':host=' . $this->host . ';dbname='. $this->dbname, $this->user, $this->pass);
            return $this->connection;
            echo "Conexão com o banco efetuada";

        } catch (Exception $e) {

            echo "Entre em contato com o administrador do sistema (00) 0000-0000";

        }
        
    }

} 

    