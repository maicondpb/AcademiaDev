<?php

class CadastraradministradorController
{
    public function novoAdministrador($adm_create){

        $adm_c = new CadastraradministradorModel();
        return $adm_c->newAdministrador($adm_create);

    }
    

}