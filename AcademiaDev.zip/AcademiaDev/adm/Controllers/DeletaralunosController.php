<?php

class DeletaralunosController
{

    public function deleteAluno($id){

        $dados_delete = new DeletaralunosModel();
        return $dados_delete->deletarAluno($id);

    }
}