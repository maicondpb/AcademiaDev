<?php

class CadastrarprofessorController
{
    public function novoProfessor($professor_create){

        $professor_c = new CadastrarprofessorModel();
        return $professor_c->newProfessor($professor_create);

    }
    

}