<?php

class AdministradoresController
{
    public function showAdministradores(){

        $dados_adm = new AdministradoresModel();
        return $dados_adm->dadosAdministrador();
    }

    public function dadosAdministradorunico($id){

        $dados_unico_adm = new AdministradoresModel();
        return $dados_unico_adm->dadosAdministradorunico($id);
        
    }

    

}

