<?php

class EditarturmasController
{

    public function editarTurma($dados_edit){
        $editarTurma = new EditarturmasModel();
        return $editarTurma->editar($dados_edit);
    }

}