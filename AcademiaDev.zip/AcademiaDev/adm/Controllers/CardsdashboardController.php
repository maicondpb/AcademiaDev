<?php

class CardsdashboardController
{
    public function listarA(){

        $quantidade_alunos = new CardsdashboardModel();
        return $quantidade_alunos->listarA();

    }

    public function listarP(){

        $quantidade_professores = new CardsdashboardModel();
        return $quantidade_professores->listarP();

    }

    public function listarT(){

        $quantidade_turmas = new CardsdashboardModel();
        return $quantidade_turmas->listarT();
        
    }

    public function listarD(){

        $quantidade_disciplinas = new CardsdashboardModel();
        return $quantidade_disciplinas->listarD();

    }

}