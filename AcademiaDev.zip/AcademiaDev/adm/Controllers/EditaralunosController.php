<?php

class EditaralunosController
{

    public function editarAluno($dados_edit){

        $editarAluno = new EditaralunosModel();
        return $editarAluno->editar($dados_edit);
    }

}