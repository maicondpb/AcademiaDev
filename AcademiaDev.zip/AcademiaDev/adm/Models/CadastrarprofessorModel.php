<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class CadastrarprofessorModel extends ConnectionController
{

    public object $conn;

    public function newProfessor($professor_create){

        
        $this->conn = $this->connectDb();

        $data = date('Y-m-d H:i:s');


        $nome = $professor_create['nome'];
        $cpf = $professor_create['cpf'];
        $email = $professor_create['email'];
        $telefone = $professor_create['telefone'];
        $sexo = $professor_create['genero'];
        $dataNascimento = date("Y-m-d",strtotime($professor_create['data_nascimento']));
        $senha = $professor_create['senha'];
        
 

       
            $sql_user = "INSERT INTO `professores`(`nome`, `cpf`, `email`, `telefone`, `sexo`, `dataNascimento`, `senha`, `nivelAcesso_id`, `situacao_id`, `dateCreate`) 
                                     VALUES ('$nome','$cpf','$email','$telefone','$sexo','$dataNascimento',md5('$senha'),3,1,'$data')";
            

            $sql_query_user = $this->conn->prepare($sql_user);

            if($sql_query_user->execute()){
                header('Location: ' . DOMINIO . 'professores');
            }else{
                header('Location: ' . DOMINIO . 'professores');
            }


    }
}   
