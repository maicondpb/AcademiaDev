<?php

session_start();

class DeletardisciplinasModel extends ConnectionController
{

    public object $conn;

    public function deletarDisciplina($id){

        $this->conn = $this->connectDb();
       
        $sql = "DELETE FROM `disciplina` WHERE `id` = $id";

        $sql_query = $this->conn->prepare($sql);

        if($sql_query->execute()){
            header('Location: ' . DOMINIO . 'disciplinas');
        }else{
            header('Location: ' . DOMINIO . 'disciplinas');
        }

    }
}