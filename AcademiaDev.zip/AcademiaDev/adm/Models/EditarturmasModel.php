<?php

session_start();

class EditarturmasModel extends ConnectionController
{

    public object $conn;

    public function editar($dados_edit){


        $this->conn = $this->connectDb();

        $sql_edit = "UPDATE `turma` SET `nome`='" . $dados_edit['nome']  . "' WHERE id =" . $dados_edit['id'];

        $sql_editTurma = $this->conn->prepare($sql_edit);

        if($sql_editTurma->execute()){
            header('Location: ' . DOMINIO . 'turmas');
        }else{
            header('Location: ' . DOMINIO . 'turmas');
        }

    }   
}