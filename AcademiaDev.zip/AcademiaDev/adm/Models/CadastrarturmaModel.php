<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class CadastrarturmaModel extends ConnectionController
{

    public object $conn;

    public function newTurma($turma_create){

        
        $this->conn = $this->connectDb();

        $data = date('Y-m-d H:i:s');

        

        $nome = $turma_create['nome'];
        
 


            $sql_turma = "INSERT INTO `turma`(`nome`, `dateCreate`) 
                                     VALUES ('$nome','$data')";
            
            var_dump($sql_turma);
            $sql_query_turma = $this->conn->prepare($sql_turma);

            if($sql_query_turma->execute()){
                header('Location: ' . DOMINIO . 'turmas');
            }else{
                header('Location: ' . DOMINIO . 'turmas');
            }


    }
}   
