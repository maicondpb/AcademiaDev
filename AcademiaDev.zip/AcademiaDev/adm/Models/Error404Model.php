<?php

class Error404Model{

    

}