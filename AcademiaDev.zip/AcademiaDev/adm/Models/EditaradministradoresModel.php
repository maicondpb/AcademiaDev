<?php

session_start();

class EditaradministradoresModel extends ConnectionController
{

    public object $conn;

    public function editar($dados_edit){


        $this->conn = $this->connectDb();


        $sql_edit = "UPDATE `administradores` SET `nome`='" . $dados_edit['nome']  . "', `email`='" . $dados_edit['email'] . "',`senha`='" . $dados_edit['senha'] ."' WHERE id =" . $dados_edit['id'];

        $sql_editAdministrador = $this->conn->prepare($sql_edit);

        if($sql_editAdministrador->execute()){
            header('Location: ' . DOMINIO . 'administradores');
        }else{
            header('Location: ' . DOMINIO . 'administradores');
        }

    }   
}