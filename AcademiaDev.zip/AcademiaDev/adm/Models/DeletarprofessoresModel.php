<?php

session_start();

class DeletarprofessoresModel extends ConnectionController
{

    public object $conn;

    public function deletarProfessor($id){

        $this->conn = $this->connectDb();
       
        $sql = "DELETE FROM `professores` WHERE `id` = $id";

        $sql_query = $this->conn->prepare($sql);

        if($sql_query->execute()){
            header('Location: ' . DOMINIO . 'professores');
        }else{
            header('Location: ' . DOMINIO . 'professores');
        }

    }
}