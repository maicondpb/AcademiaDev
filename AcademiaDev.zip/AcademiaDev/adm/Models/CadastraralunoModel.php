<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class CadastraralunoModel extends ConnectionController
{

    public object $conn;

    public function newAluno($aluno_create){
        
        $this->conn = $this->connectDb();

        $data = date('Y-m-d H:i:s');

        

        $nome = $aluno_create['nome'];
        $cpf = $aluno_create['cpf'];
        $email = $aluno_create['email'];
        $telefone = $aluno_create['telefone'];
        $sexo = $aluno_create['genero'];
        $dataNascimento = date("Y-m-d",strtotime($aluno_create['data_nascimento']));
        $senha = $aluno_create['senha'];
        $estado = $aluno_create['estado'];
        $cidade = $aluno_create['cidade'];
        $bairro = $aluno_create['bairro'];
        $rua = $aluno_create['rua'];
        $numero = $aluno_create['numero'];
        $complemento = $aluno_create['complemento'];  
        $cep = $aluno_create['cep'];
        
 


            $sql_user = "INSERT INTO `alunos`(`nome`, `cpf`, `email`, `telefone`, `sexo`, `dataNascimento`, `senha`, `estado`, `cidade`, `bairro`, `rua`, `numero`, `complemento`, `cep`, `turma_id`, `nivelAcesso_id`, `situacao_id`, `dateCreate`) 
                                     VALUES ('$nome','$cpf','$email','$telefone','$sexo','$dataNascimento',md5('$senha'),'$estado','$cidade','$bairro','$rua','$numero','$complemento','$cep',2,2,1,'$data')";
            
            $sql_query_user = $this->conn->prepare($sql_user);

            if($sql_query_user->execute()){
                header('Location: ' . DOMINIO . 'alunos');
            }else{
                header('Location: ' . DOMINIO . 'alunos');
            }


    }
}   
