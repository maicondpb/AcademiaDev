<?php

session_start();

class DeletaralunosModel extends ConnectionController
{

    public object $conn;

    public function deletarAluno($id){

        $this->conn = $this->connectDb();
       
        $sql = "DELETE FROM `alunos` WHERE `id` = $id";
        $sql_query = $this->conn->prepare($sql);

        if($sql_query->execute()){
            header('Location: ' . DOMINIO . 'alunos');
        }else{
            header('Location: ' . DOMINIO . 'alunos');
        }

    }
}