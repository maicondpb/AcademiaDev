<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class AlunosModel extends ConnectionController
{

    public object $conn;
    
    public function dadosAluno(){

        $this->conn = $this->connectDb();

        $sql = "SELECT * from alunos  ORDER BY nome ASC";
        $sql_query = $this->conn->prepare($sql);
        $sql_query->execute();

        $sql_dadosAluno = $sql_query->fetchAll();
        return $sql_dadosAluno;

    }

    public function dadosAlunounico($id){

        $this->conn = $this->connectDb();

        $sql_unico = "SELECT * from alunos WHERE id = " . $id;
        $sql_query_unico = $this->conn->prepare($sql_unico);
        $sql_query_unico->execute();

        $sql_dadosAlunounico = $sql_query_unico->fetchAll();
        return $sql_dadosAlunounico;
    }


    

   
}