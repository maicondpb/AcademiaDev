<?php

class DashboardModel{



}