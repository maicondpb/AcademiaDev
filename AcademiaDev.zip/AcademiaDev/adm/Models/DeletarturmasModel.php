<?php

session_start();

class DeletarturmasModel extends ConnectionController
{

    public object $conn;

    public function deletarTurma($id){

        $this->conn = $this->connectDb();
       
        $sql = "DELETE FROM `turma` WHERE `id` = $id";

        $sql_query = $this->conn->prepare($sql);

        if($sql_query->execute()){
            header('Location: ' . DOMINIO . 'turmas');
        }else{
            header('Location: ' . DOMINIO . 'turmas');
        }

    }
}