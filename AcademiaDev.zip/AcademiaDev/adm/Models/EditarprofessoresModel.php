<?php

session_start();

class EditarprofessoresModel extends ConnectionController
{

    public object $conn;

    public function editar($dados_edit){


        $this->conn = $this->connectDb();

        $dataNascimento = date('Y-m-d', strtotime($dados_edit['data_nascimento']));

        $sql_edit = "UPDATE `professores` SET `nome`='" . $dados_edit['nome']  . "', `cpf`='" . $dados_edit['cpf'] . "', `email`='" . $dados_edit['email'] . "',`telefone`='" . $dados_edit['telefone']  . "',`sexo`='" . $dados_edit['genero'] . "',`dataNascimento`='$dataNascimento',`senha`='" . $dados_edit['senha'] ."' WHERE id =" . $dados_edit['id'];

        $sql_editProfessor = $this->conn->prepare($sql_edit);

        if($sql_editProfessor->execute()){
            header('Location: ' . DOMINIO . 'professores');
        }else{
            header('Location: ' . DOMINIO . 'professores');
        }

    }   
}