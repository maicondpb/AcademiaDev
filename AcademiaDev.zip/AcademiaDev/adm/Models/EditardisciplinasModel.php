<?php

session_start();

class EditardisciplinasModel extends ConnectionController
{

    public object $conn;

    public function editar($dados_edit){


        $this->conn = $this->connectDb();

        $sql_edit = "UPDATE `disciplina` SET `nome`='" . $dados_edit['nome']  . "' WHERE id =" . $dados_edit['id'];

        $sql_editDisciplina = $this->conn->prepare($sql_edit);

        if($sql_editDisciplina->execute()){
            header('Location: ' . DOMINIO . 'disciplinas');
        }else{
            header('Location: ' . DOMINIO . 'disciplinas');
        }

    }   
}