<?php

session_start();

class DeletaradministradoresModel extends ConnectionController
{

    public object $conn;

    public function deletarAdministrador($id){

        $this->conn = $this->connectDb();
       
        $sql = "DELETE FROM `administradores` WHERE `id` = $id";

        $sql_query = $this->conn->prepare($sql);

        if($sql_query->execute()){
            header('Location: ' . DOMINIO . 'administradores');
        }else{
            header('Location: ' . DOMINIO . 'administradores');
        }

    }
}