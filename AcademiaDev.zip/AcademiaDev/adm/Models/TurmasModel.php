<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class TurmasModel extends ConnectionController
{

    public object $conn;
    
    public function dadosTurma(){

        $this->conn = $this->connectDb();

        $sql = "SELECT * from turma ORDER BY nome ASC";
        $sql_query = $this->conn->prepare($sql);
        $sql_query->execute();

        $sql_dadosTurma = $sql_query->fetchAll();
        return $sql_dadosTurma;

    }

    public function dadosTurmaunico($id){

        $this->conn = $this->connectDb();

        $sql_unico = "SELECT * from turma WHERE id = " . $id;
        $sql_query_unico = $this->conn->prepare($sql_unico);
        $sql_query_unico->execute();

        $sql_dadosTurmaunico = $sql_query_unico->fetchAll();
        return $sql_dadosTurmaunico;
    }
}