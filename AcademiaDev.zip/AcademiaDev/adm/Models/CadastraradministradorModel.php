<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class CadastraradministradorModel extends ConnectionController
{

    public object $conn;

    public function newAdministrador($adm_create){

        
        $this->conn = $this->connectDb();

        $data = date('Y-m-d H:i:s');


        $nome = $adm_create['nome'];
        $email = $adm_create['email'];
        $senha = $adm_create['senha'];
        
 

       
            $sql_user = "INSERT INTO `administradores`(`nome`, `email`, `senha`, `nivelAcesso_id`, `dateCreate`) 
                                     VALUES ('$nome','$email',md5('$senha'),1,'$data')";
            
            $sql_query_user = $this->conn->prepare($sql_user);

            if($sql_query_user->execute()){
                header('Location: ' . DOMINIO . 'administradores');
            }else{
                header('Location: ' . DOMINIO . 'administradores');
            }


    }
}   
