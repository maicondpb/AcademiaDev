<?php

session_start();

class EditaralunosModel extends ConnectionController
{

    public object $conn;

    public function editar($dados_edit){


        $this->conn = $this->connectDb();

        $dataNascimento = date('Y-m-d', strtotime($dados_edit['data_nascimento']));

        $sql_edit = "UPDATE `alunos` SET `nome`='" . $dados_edit['nome']  . "', `cpf`='" . $dados_edit['cpf'] . "', `email`='" . $dados_edit['email'] . "',`telefone`='" . $dados_edit['telefone']  . "',`sexo`='" . $dados_edit['genero'] . "',`dataNascimento`='$dataNascimento',`senha`='" . $dados_edit['senha']  . "',`estado`='" . $dados_edit['estado'] . "',`cidade`='" . $dados_edit['cidade'] ."',`bairro`='" . $dados_edit['bairro'] ."',`rua`='" . $dados_edit['rua'] ."',`numero`='" . $dados_edit['numero'] ."',`complemento`='" . $dados_edit['complemento'] ."',`cep`='" . $dados_edit['cep'] ."' WHERE id =" . $dados_edit['id'];

        $sql_editAluno = $this->conn->prepare($sql_edit);

        if($sql_editAluno->execute()){

            header('Location: ' . DOMINIO . 'alunos');
        }else{
            header('Location: ' . DOMINIO . 'alunos');
        }

    }
}