<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class CardsdashboardModel extends ConnectionController
{

    public object $conn;

    public function listarA(){

        $this->conn = $this->connectDb();

        $sql = "SELECT COUNT(*) AS num_alunos FROM `alunos`";
        $sql_query = $this->conn->prepare($sql);
        $sql_query->execute();

        $sql_quantidadeAluno = $sql_query->fetchAll();
        return $sql_quantidadeAluno[0]['num_alunos'];
    }

    public function listarP(){

        $this->conn = $this->connectDb();

        $sql = "SELECT COUNT(*) AS num_professores FROM `professores`";
        $sql_query = $this->conn->prepare($sql);
        $sql_query->execute();

        $sql_quantidadeProfessor = $sql_query->fetchAll();
        return $sql_quantidadeProfessor[0]['num_professores'];
    }

    public function listarT(){

        $this->conn = $this->connectDb();

        $sql = "SELECT COUNT(*) AS num_turmas FROM `turma`";
        $sql_query = $this->conn->prepare($sql);
        $sql_query->execute();

        $sql_quantidadeTurma = $sql_query->fetchAll();
        return $sql_quantidadeTurma[0]['num_turmas'];
    }

    public function listarD(){

        $this->conn = $this->connectDb();

        $sql = "SELECT COUNT(*) AS num_disciplinas FROM `disciplina`";
        $sql_query = $this->conn->prepare($sql);
        $sql_query->execute();

        $sql_quantidadeDisciplina = $sql_query->fetchAll();
        return $sql_quantidadeDisciplina[0]['num_disciplinas'];
    }



}