<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class CadastrardisciplinaModel extends ConnectionController
{

    public object $conn;

    public function newDisciplina($disciplina_create){

        
        $this->conn = $this->connectDb();

        $data = date('Y-m-d H:i:s');

        

        $nome = $disciplina_create['nome'];
        
 


            $sql_disciplina = "INSERT INTO `disciplina`(`nome`, `dateCreate`) 
                                     VALUES ('$nome','$data')";
            
            $sql_query_disciplina = $this->conn->prepare($sql_disciplina);

            if($sql_query_disciplina->execute()){
                header('Location: ' . DOMINIO . 'disciplinas');
            }else{
                header('Location: ' . DOMINIO . 'disciplinas');
            }


    }
}   
