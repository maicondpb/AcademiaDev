<?php

class LogoutModel{

    

}