<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');

class DisciplinasModel extends ConnectionController
{

    public object $conn;
    
    public function dadosDisciplina(){

        $this->conn = $this->connectDb();

        $sql = "SELECT * from disciplina ORDER BY nome ASC";
        $sql_query = $this->conn->prepare($sql);
        $sql_query->execute();

        $sql_dadosDisciplina = $sql_query->fetchAll();
        return $sql_dadosDisciplina;

    }

    public function dadosDisciplinaunico($id){

        $this->conn = $this->connectDb();

        $sql_unico = "SELECT * from disciplina WHERE id = " . $id;
        $sql_query_unico = $this->conn->prepare($sql_unico);
        $sql_query_unico->execute();

        $sql_dadosDisciplinaunico = $sql_query_unico->fetchAll();
        return $sql_dadosDisciplinaunico;
    }
}