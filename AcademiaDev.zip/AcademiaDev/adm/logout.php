<?php

session_start();


unset($_SESSION['id']);

            unset($_SESSION['nivelAcesso_id']);
            unset($_SESSION['nome'] );
            unset($_SESSION['situacao_id']);


            session_destroy();

header("Location: " . DOMINIO . "login");
