<?php

class Core
{

    public function index($controller, $metodo, $parametro){
        
        if($controller != ""){

            $class   = ucfirst($controller) . "Controller";
            $caminho = "/var/www/html/Controllers/" . $class . ".php";
           
            if(file_exists($caminho)){
                
                if(class_exists($class)){ 
                    
                    if(method_exists($class,$metodo)){
                        echo "chegou no metodo";

                        if($parametro != ""){

                            call_user_func_array(array(new $class,$metodo),$parametro);
                        }else{
                            call_user_func_array(array(new $class,$metodo),array());
                        }

                        include_once "/var/www/html/Views/" . $controller . ".php";

                    }else{
                        include_once "/var/www/html/Views/" . $controller . ".php";
                    }

                }else{
                    echo "não existe classe";
                }
                

            }else{
                    include_once "/var/www/html/Views/login.php";

            }

        }else{
            include_once "/var/www/html/Views/login.php";
        }

    }

}