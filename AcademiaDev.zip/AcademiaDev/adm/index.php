<?php
session_start();


define('C7E3L8K9E58743', true);

$url = filter_input(INPUT_GET,'url_adm',FILTER_DEFAULT);

//Config
include_once 'config/config.php';

//core
include_once "core/Core.php";

//Controllers
include_once 'Controllers/ConnectionController.php';
include_once 'Controllers/UsuarioController.php';
include_once 'Controllers/Error404Controller.php';
include_once 'Controllers/DashboardController.php';
include_once 'Controllers/CadastraralunoController.php';
include_once 'Controllers/ProfessoresController.php';
include_once 'Controllers/CadastrarprofessorController.php';
include_once 'Controllers/AlunosController.php';
include_once 'Controllers/CadastrarturmaController.php';
include_once 'Controllers/TurmasController.php';
include_once 'Controllers/DisciplinasController.php';
include_once 'Controllers/CadastrardisciplinaController.php';
include_once 'Controllers/DeletaralunosController.php';
include_once 'Controllers/DeletarprofessoresController.php';
include_once 'Controllers/EditaralunosController.php';
include_once 'Controllers/DeletarturmasController.php';
include_once 'Controllers/DeletardisciplinasController.php';
include_once 'Controllers/LogoutController.php';
include_once 'Controllers/EditarturmasController.php';
include_once 'Controllers/EditardisciplinasController.php';
include_once 'Controllers/EditarprofessoresController.php';
include_once 'Controllers/AdministradoresController.php';
include_once 'Controllers/CadastraradministradorController.php';
include_once 'Controllers/DeletaradministradoresController.php';
include_once 'Controllers/EditaradministradoresController.php';
include_once 'Controllers/CardsdashboardController.php';



//Model
include_once 'Models/UsuarioModel.php';
include_once 'Controllers/Error404Model.php';
include_once 'Models/DashboardModel.php';
include_once 'Models/CadastraralunoModel.php';
include_once 'Models/ProfessoresModel.php';
include_once 'Models/CadastrarprofessorModel.php';
include_once 'Models/AlunosModel.php';
include_once 'Models/CadastrarturmaModel.php';
include_once 'Models/TurmasModel.php';
include_once 'Models/DisciplinasModel.php';
include_once 'Models/CadastrardisciplinaModel.php';
include_once 'Models/DeletaralunosModel.php';
include_once 'Models/DeletarprofessoresModel.php';
include_once 'Models/EditaralunosModel.php';
include_once 'Models/DeletarturmasModel.php';
include_once 'Models/DeletardisciplinasModel.php';
include_once 'Models/LogoutModel.php';
include_once 'Models/EditarturmasModel.php';
include_once 'Models/EditardisciplinasModel.php';
include_once 'Models/EditarprofessoresModel.php';
include_once 'Models/AdministradoresModel.php';
include_once 'Models/CadastraradministradorModel.php';
include_once 'Models/DeletaradministradoresModel.php';
include_once 'Models/EditaradministradoresModel.php';
include_once 'Models/CardsdashboardModel.php';



$arr_url = explode("/",$url);

$controller  = $arr_url[0];
$metodo    = $arr_url[1];
$parametro = $arr_url[2];


$index = new Core();
$index->index($controller, $metodo, $parametro);

if($_POST){
    $email = trim(filter_input(INPUT_POST,'email',FILTER_DEFAULT));
    $senha = trim(filter_input(INPUT_POST,'password',FILTER_DEFAULT));

    if(!empty($email) && !empty($senha)){

        $index = new UsuarioController();

        $p = $index->loginSystem($email,$senha);

        if($p == 1){
            header("Location: " . DOMINIO . "dashboard");
        }else{
            
            header("Location: " . DOMINIO);
        }  

    }else{
        header("Location: " . DOMINIO);
    }
}

